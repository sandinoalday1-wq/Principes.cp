import { products, reviews } from './data.js';

document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();

    const mobileMenuBtn = document.getElementById("mobile-menu-btn");
    const mobileMenu = document.getElementById("mobile-menu");
    
    mobileMenuBtn.addEventListener("click", () => {
        mobileMenu.classList.toggle("hidden");
    });

    const productsGrid = document.getElementById("products-grid");
    if (productsGrid) {
        const productsHTML = products.map(product => `
            <div class="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-300 group gs-reveal-up">
                <div class="h-64 overflow-hidden relative">
                    <img src="${product.img}" alt="${product.title}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-in-out">
                    <div class="absolute inset-0 bg-dark-green/20 group-hover:bg-transparent transition-colors duration-300"></div>
                </div>
                <div class="p-6">
                    <h3 class="font-serif text-xl font-bold text-dark-green mb-2">${product.title}</h3>
                    <p class="text-neutral-600 text-sm leading-relaxed">${product.desc}</p>
                </div>
            </div>
        `).join("");
        productsGrid.innerHTML = productsHTML;
    }

    const reviewsContainer = document.getElementById("reviews-container");
    if (reviewsContainer) {
        const reviewsHTML = reviews.map(review => `
            <div class="bg-cream p-8 rounded-2xl border border-gold/10 relative">
                <i data-lucide="quote" class="w-8 h-8 text-gold/30 absolute top-6 right-6"></i>
                <div class="flex items-center gap-1 mb-4">
                    <i data-lucide="star" class="w-4 h-4 text-gold fill-gold"></i>
                    <i data-lucide="star" class="w-4 h-4 text-gold fill-gold"></i>
                    <i data-lucide="star" class="w-4 h-4 text-gold fill-gold"></i>
                    <i data-lucide="star" class="w-4 h-4 text-gold fill-gold"></i>
                    <i data-lucide="star" class="w-4 h-4 text-gold fill-gold"></i>
                </div>
                <p class="text-neutral-600 italic mb-6">"${review.text}"</p>
                <div class="flex justify-between items-center">
                    <span class="font-bold text-dark-green">${review.author}</span>
                    <span class="text-xs text-neutral-400">${review.date}</span>
                </div>
            </div>
        `).join("");
        reviewsContainer.innerHTML = reviewsHTML;
        lucide.createIcons();
    }

    gsap.registerPlugin(ScrollTrigger);

    const nav = document.getElementById("navbar");
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            nav.classList.add("shadow-md");
        } else {
            nav.classList.remove("shadow-md");
        }
    });

    gsap.utils.toArray('.gs-reveal').forEach(function(elem) {
        gsap.fromTo(elem, 
            { autoAlpha: 0, y: 30 }, 
            { autoAlpha: 1, y: 0, duration: 1, ease: "power2.out", 
              scrollTrigger: { trigger: elem, start: "top 85%" } 
            }
        );
    });

    gsap.utils.toArray('.gs-reveal-up').forEach(function(elem) {
        gsap.fromTo(elem, 
            { autoAlpha: 0, y: 50 }, 
            { autoAlpha: 1, y: 0, duration: 0.8, ease: "power2.out", stagger: 0.2,
              scrollTrigger: { trigger: elem, start: "top 85%" } 
            }
        );
    });

    gsap.utils.toArray('.gs-reveal-left').forEach(function(elem) {
        gsap.fromTo(elem, 
            { autoAlpha: 0, x: -50 }, 
            { autoAlpha: 1, x: 0, duration: 1, ease: "power2.out",
              scrollTrigger: { trigger: elem, start: "top 85%" } 
            }
        );
    });

    gsap.utils.toArray('.gs-reveal-right').forEach(function(elem) {
        gsap.fromTo(elem, 
            { autoAlpha: 0, x: 50 }, 
            { autoAlpha: 1, x: 0, duration: 1, ease: "power2.out",
              scrollTrigger: { trigger: elem, start: "top 85%" } 
            }
        );
    });
});
