export const products =[
    {
        id: 1,
        title: "Panes Artesanales",
        desc: "Masa madre, baguettes y panes rústicos horneados diariamente.",
        img: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?auto=format&fit=crop&q=80"
    },
    {
        id: 2,
        title: "Bizcochos",
        desc: "Clásicos uruguayos, hojaldrados, dulces y salados, perfectos para acompañar.",
        img: "https://images.unsplash.com/photo-1608198093002-ad4e005484ec?auto=format&fit=crop&q=80"
    },
    {
        id: 3,
        title: "Tortas",
        desc: "Para toda ocasión. Elaboradas con ingredientes de la más alta calidad.",
        img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80"
    },
    {
        id: 4,
        title: "Especialidades Dulces",
        desc: "Postres, masitas finas y delicias exclusivas de la casa.",
        img: "https://images.unsplash.com/photo-1483695028939-5bb13f8648b0?auto=format&fit=crop&q=80"
    }
];

export const reviews =[
    {
        id: 1,
        author: "María L.",
        text: "Los mejores bizcochos de Mercedes. Siempre frescos y con ese sabor artesanal inconfundible. ¡La atención es excelente!",
        date: "Hace 2 semanas"
    },
    {
        id: 2,
        author: "Carlos D.",
        text: "Compré una torta para un cumpleaños y superó mis expectativas. Materiales de primera calidad y diseño hermoso.",
        date: "Hace 1 mes"
    },
    {
        id: 3,
        author: "Ana F.",
        text: "El pan de masa madre es un viaje de ida. Desde que abren a las 5pm el aroma invita a entrar. Muy recomendado.",
        date: "Hace 2 meses"
    }
];
